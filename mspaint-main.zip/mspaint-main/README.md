# mspaint
A decent roblox doors script. Free and Open Source 🥶

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/notpoiu/mspaint/main/main.lua"))()
```

**Links**:
- [🌐 Website](https://mspaint.upio.dev/)
- [💬 Discord](https://discord.com/invite/cfyMptntHr)
